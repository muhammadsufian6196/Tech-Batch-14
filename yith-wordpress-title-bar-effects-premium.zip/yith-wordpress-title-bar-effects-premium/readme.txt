== YITH WordPress Title Bar Effects ===

== Changelog ==

= 1.1.12 - Released: 10 March 2021 =

* New: support for WordPress 5.7
* Update: YITH plugin framework

= 1.1.11 - Released: 04 December 2020 =

* New: support for WordPress 5.6
* Update: plugin framework

= 1.1.10 - Released: 19 August 2020 =

* New: support for WordPress 5.5
* Update: plugin framework

= 1.1.9 - Released: 29 May 2020 =

* New: support for WordPress 5.4.1
* Update: plugin fw
* Fix: enable plugin effects on change page tab

= 1.1.8 - Released: 05 November 2019 =

* New: support for WordPress 5.3
* Update: plugin framework

= 1.1.7 - Released: 30 October 2019 =

* New: support for WordPress 5.3
* Update: plugin framework

= 1.1.6 - Released: 25 June 2019 =

* Update: plugin framework

= 1.1.5 - Released: 31 May 2019 =

* Update: plugin framework

= 1.1.4 - Released: 21 May 2019 =

* Update: plugin framework 3.2.1
* Update: Spanish language
* Fix: animation not working switching tab

= 1.1.3 - Released: 20 February 2019 =

* Update: Core Framework 3.1.20
* Update: Italian translation
* Update: Dutch translation

= 1.1.2 - Released: 23 October 2018 =

* Update: Core Framework 3.0.27

= 1.1.1 - Released: 27 September 2018 =

* Update: Core Framework 3.0.23

= 1.1.0 - Released: 24 April 2018 =

* New: plugin fw version 3.0.15
* New: Spanish translation
* New: Dutch translation
* New: Italian translation

= 1.0.1 - Released: 12 January 2017 =

* New: integration with YITH Desktop Notifications for WooCommerce

= 1.0.0 - Released: 24 October 2016 =

* Initial release